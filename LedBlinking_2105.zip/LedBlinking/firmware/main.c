#include <LPC210x.H>    

int main()
{ int i;

	IODIR=0x00000080;//set output register
	
	
	while(1){
	IOSET=0x00000080;// set high for register
	for (i=0; i<10000;i++);
  IOCLR=0x00000080;
	for (i=0; i<5000;i++);//  clear register

	}

	
}